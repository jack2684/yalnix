/* Team 3: stderr, Junjie Guan, Ziyang Wang*/
#ifndef _TTY_H
#define _TTY_H
struct y_TTY {

};

#endif

