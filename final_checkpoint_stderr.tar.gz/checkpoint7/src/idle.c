/* Team 3: stderr, Junjie Guan, Ziyang Wang*/
void main(void) {
    while(1) {
        TracePrintf(5, "KEEP IDLING...\n");
        Pause();
    }
}
