/* Team 3: stderr, Junjie Guan, Ziyang Wang*/
#include "vector.h"

void **vector_init() {
    return NULL; 
}

