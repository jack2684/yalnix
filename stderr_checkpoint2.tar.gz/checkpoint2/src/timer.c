#include "kernelLib.h"

int Y_Delay(int clock_ticks){
	//IF clock_ticks < 0
		//REPORT ERROR
	//END IF

	//IF clock_ticks == 0
		//RETURN 
	//END IF

	//SET remaining clock_ticks to the current clock_ticks
	//BLOCK the calling process with the clock_ticks
}
