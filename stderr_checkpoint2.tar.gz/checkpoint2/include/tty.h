#ifndef _TTY_H
#define _TTY_H
struct y_TTY {

};

#endif

