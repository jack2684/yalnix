#ifndef _VECTOR_H
#define _VECTOR_H
#include "standardLib.h"
typedef struct y_Vector {
    int size;
    int rc;
    void *arr;
} vector_t;
#endif
