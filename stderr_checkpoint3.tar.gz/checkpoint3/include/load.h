#ifndef _LOAD_H
#define _LOAD_H

#define KILL 1      // Meaning unkown yet

int LoadProgram(char *name, char *args[], pcb_t *proc);

#endif
