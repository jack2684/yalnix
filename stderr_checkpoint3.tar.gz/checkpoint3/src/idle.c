void main(void) {
    while(1) {
        TracePrintf(1, "KEEP IDLING...\n");
        Pause();
    }
}
