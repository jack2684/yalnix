#include "vector.h"

void **vector_init() {
    return NULL; 
}

